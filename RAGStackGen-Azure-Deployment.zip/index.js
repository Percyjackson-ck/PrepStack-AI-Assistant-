var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/index.ts
import "dotenv/config";
import express2 from "express";

// server/routes.ts
import { createServer } from "http";

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  chatSessions: () => chatSessions,
  chatSessionsRelations: () => chatSessionsRelations,
  githubRepos: () => githubRepos,
  githubReposRelations: () => githubReposRelations,
  insertChatSessionSchema: () => insertChatSessionSchema,
  insertGithubRepoSchema: () => insertGithubRepoSchema,
  insertNoteSchema: () => insertNoteSchema,
  insertPlacementQuestionSchema: () => insertPlacementQuestionSchema,
  insertUserSchema: () => insertUserSchema,
  notes: () => notes,
  notesRelations: () => notesRelations,
  placementQuestions: () => placementQuestions,
  placementQuestionsRelations: () => placementQuestionsRelations,
  users: () => users,
  usersRelations: () => usersRelations
});
import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
var users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  githubToken: text("github_token"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var notes = pgTable("notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  content: text("content").notNull(),
  subject: text("subject").notNull(),
  fileType: text("file_type").notNull(),
  fileName: text("file_name").notNull(),
  embedding: text("embedding"),
  // JSON string of vector embedding
  uploadedAt: timestamp("uploaded_at").defaultNow().notNull()
});
var githubRepos = pgTable("github_repos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  repoName: text("repo_name").notNull(),
  description: text("description"),
  language: text("language"),
  stars: integer("stars").default(0),
  lastAnalyzed: timestamp("last_analyzed"),
  analysis: jsonb("analysis"),
  // Store code analysis results
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var placementQuestions = pgTable("placement_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  company: text("company").notNull(),
  question: text("question").notNull(),
  difficulty: text("difficulty").notNull(),
  topic: text("topic").notNull(),
  solution: text("solution"),
  year: integer("year").notNull(),
  embedding: text("embedding"),
  // JSON string of vector embedding
  isSolved: boolean("is_solved").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var chatSessions = pgTable("chat_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  messages: jsonb("messages").notNull(),
  // Array of message objects
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});
var usersRelations = relations(users, ({ many }) => ({
  notes: many(notes),
  githubRepos: many(githubRepos),
  placementQuestions: many(placementQuestions),
  chatSessions: many(chatSessions)
}));
var notesRelations = relations(notes, ({ one }) => ({
  user: one(users, { fields: [notes.userId], references: [users.id] })
}));
var githubReposRelations = relations(githubRepos, ({ one }) => ({
  user: one(users, { fields: [githubRepos.userId], references: [users.id] })
}));
var placementQuestionsRelations = relations(placementQuestions, ({ one }) => ({
  user: one(users, { fields: [placementQuestions.userId], references: [users.id] })
}));
var chatSessionsRelations = relations(chatSessions, ({ one }) => ({
  user: one(users, { fields: [chatSessions.userId], references: [users.id] })
}));
var insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true
});
var insertNoteSchema = createInsertSchema(notes).omit({
  id: true,
  uploadedAt: true,
  embedding: true
});
var insertGithubRepoSchema = createInsertSchema(githubRepos).omit({
  id: true,
  createdAt: true,
  lastAnalyzed: true,
  analysis: true
});
var insertPlacementQuestionSchema = createInsertSchema(placementQuestions).omit({
  id: true,
  createdAt: true,
  embedding: true
});
var insertChatSessionSchema = createInsertSchema(chatSessions).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

// server/db.ts
import { Pool, neonConfig } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";
neonConfig.webSocketConstructor = ws;
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?"
  );
}
var pool = new Pool({ connectionString: process.env.DATABASE_URL });
var db = drizzle({ client: pool, schema: schema_exports });

// server/storage.ts
import { eq, desc, like, and, or } from "drizzle-orm";
var DatabaseStorage = class {
  async getUser(id) {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || void 0;
  }
  async getUserByEmail(email) {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || void 0;
  }
  async createUser(insertUser) {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  async updateUser(id, updates) {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user || void 0;
  }
  async createNote(insertNote) {
    const [note] = await db.insert(notes).values(insertNote).returning();
    return note;
  }
  async getNotesByUser(userId) {
    return await db.select().from(notes).where(eq(notes.userId, userId)).orderBy(desc(notes.uploadedAt));
  }
  async getNotesBySubject(userId, subject) {
    return await db.select().from(notes).where(and(eq(notes.userId, userId), eq(notes.subject, subject))).orderBy(desc(notes.uploadedAt));
  }
  async searchNotes(userId, query) {
    return await db.select().from(notes).where(and(
      eq(notes.userId, userId),
      or(
        like(notes.title, `%${query}%`),
        like(notes.content, `%${query}%`)
      )
    )).orderBy(desc(notes.uploadedAt));
  }
  async updateNoteEmbedding(id, embedding) {
    await db.update(notes).set({ embedding }).where(eq(notes.id, id));
  }
  async getNoteById(id) {
    const [note] = await db.select().from(notes).where(eq(notes.id, id));
    return note;
  }
  async deleteNote(id) {
    await db.delete(notes).where(eq(notes.id, id));
  }
  async createGithubRepo(insertRepo) {
    const [repo] = await db.insert(githubRepos).values(insertRepo).returning();
    return repo;
  }
  async getGithubReposByUser(userId) {
    return await db.select().from(githubRepos).where(eq(githubRepos.userId, userId)).orderBy(desc(githubRepos.createdAt));
  }
  async updateGithubRepoAnalysis(id, analysis) {
    await db.update(githubRepos).set({ analysis, lastAnalyzed: /* @__PURE__ */ new Date() }).where(eq(githubRepos.id, id));
  }
  async createPlacementQuestion(insertQuestion) {
    const [question] = await db.insert(placementQuestions).values(insertQuestion).returning();
    return question;
  }
  async getPlacementQuestionsByUser(userId) {
    return await db.select().from(placementQuestions).where(eq(placementQuestions.userId, userId)).orderBy(desc(placementQuestions.createdAt));
  }
  async searchPlacementQuestions(userId, filters) {
    const conditions = [eq(placementQuestions.userId, userId)];
    if (filters.company) {
      conditions.push(eq(placementQuestions.company, filters.company));
    }
    if (filters.year) {
      conditions.push(eq(placementQuestions.year, filters.year));
    }
    if (filters.difficulty) {
      conditions.push(eq(placementQuestions.difficulty, filters.difficulty));
    }
    if (filters.topic) {
      conditions.push(like(placementQuestions.topic, `%${filters.topic}%`));
    }
    return await db.select().from(placementQuestions).where(and(...conditions)).orderBy(desc(placementQuestions.createdAt));
  }
  async updateQuestionEmbedding(id, embedding) {
    await db.update(placementQuestions).set({ embedding }).where(eq(placementQuestions.id, id));
  }
  async createChatSession(insertSession) {
    const [session] = await db.insert(chatSessions).values(insertSession).returning();
    return session;
  }
  async getChatSessionsByUser(userId) {
    return await db.select().from(chatSessions).where(eq(chatSessions.userId, userId)).orderBy(desc(chatSessions.updatedAt));
  }
  async updateChatSession(id, messages) {
    const [session] = await db.update(chatSessions).set({ messages, updatedAt: /* @__PURE__ */ new Date() }).where(eq(chatSessions.id, id)).returning();
    return session || void 0;
  }
  async deleteChatSessionsByUser(userId) {
    await db.delete(chatSessions).where(eq(chatSessions.userId, userId));
  }
};
var storage = new DatabaseStorage();

// server/services/fileProcessor.ts
import * as fs from "fs";
import * as path from "path";
var FileProcessor = class {
  static async processFile(filePath, originalName) {
    const extension = path.extname(originalName).toLowerCase();
    const title = path.basename(originalName, extension);
    switch (extension) {
      case ".pdf":
        return await this.processPDF(filePath, title);
      case ".docx":
        return await this.processDocx(filePath, title);
      case ".md":
        return await this.processMarkdown(filePath, title);
      case ".txt":
        return await this.processText(filePath, title);
      default:
        throw new Error(`Unsupported file type: ${extension}`);
    }
  }
  static async processPDF(filePath, title) {
    try {
      const content = `PDF file: ${title}

This is a placeholder for PDF content extraction. To enable full PDF processing, install and configure a PDF parsing library like pdf-parse or pdfjs-dist.`;
      return {
        content,
        title,
        fileType: "pdf"
      };
    } catch (error) {
      throw new Error(`Failed to process PDF: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
  static async processDocx(filePath, title) {
    try {
      const content = `DOCX file: ${title}

This is a placeholder for DOCX content extraction. To enable full DOCX processing, install and configure the mammoth library.`;
      return {
        content,
        title,
        fileType: "docx"
      };
    } catch (error) {
      throw new Error(`Failed to process DOCX: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
  static async processMarkdown(filePath, title) {
    try {
      const content = fs.readFileSync(filePath, "utf-8");
      return {
        content: content.trim(),
        title,
        fileType: "markdown"
      };
    } catch (error) {
      throw new Error(`Failed to process Markdown: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
  static async processText(filePath, title) {
    try {
      const content = fs.readFileSync(filePath, "utf-8");
      return {
        content: content.trim(),
        title,
        fileType: "text"
      };
    } catch (error) {
      throw new Error(`Failed to process text file: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
  static async createEmbedding(text2) {
    const words = text2.toLowerCase().split(/\s+/);
    const wordFreq = {};
    words.forEach((word) => {
      word = word.replace(/[^\w]/g, "");
      if (word.length > 2) {
        wordFreq[word] = (wordFreq[word] || 0) + 1;
      }
    });
    const vector = Object.entries(wordFreq).sort(([, a], [, b]) => b - a).slice(0, 100).map(([word, freq]) => freq);
    return JSON.stringify(vector);
  }
  static calculateSimilarity(embedding1, embedding2) {
    try {
      const vec1 = JSON.parse(embedding1);
      const vec2 = JSON.parse(embedding2);
      const maxLength = Math.max(vec1.length, vec2.length);
      let dotProduct = 0;
      let norm1 = 0;
      let norm2 = 0;
      for (let i = 0; i < maxLength; i++) {
        const v1 = vec1[i] || 0;
        const v2 = vec2[i] || 0;
        dotProduct += v1 * v2;
        norm1 += v1 * v1;
        norm2 += v2 * v2;
      }
      const magnitude = Math.sqrt(norm1) * Math.sqrt(norm2);
      return magnitude === 0 ? 0 : dotProduct / magnitude;
    } catch {
      return 0;
    }
  }
};

// server/services/groqService.ts
import OpenAI from "openai";
var GroqService = class {
  client;
  constructor() {
    this.client = new OpenAI({
      baseURL: "https://api.groq.com/openai/v1",
      apiKey: process.env.GROQ_API_KEY || "default_key"
    });
  }
  async generateAnswer(query, context) {
    try {
      const systemPrompt = `You are an AI study assistant specializing in computer science topics, placement preparation, and code analysis. 
      
      You have access to the user's personal study materials, notes, GitHub repositories, and placement questions. 
      Use the provided context to give accurate, detailed answers.
      
      When referencing sources, mention which document or repository the information comes from.
      
      Keep answers focused, practical, and educational.`;
      const userPrompt = `Question: ${query}

Context from user's materials:
${context}

Please provide a comprehensive answer based on the context provided.`;
      const response = await this.client.chat.completions.create({
        model: "llama3-8b-8192",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        max_tokens: 1e3,
        temperature: 0.7
      });
      return response.choices[0]?.message?.content || "I couldn't generate a response. Please try again.";
    } catch (error) {
      console.error("Grok API error:", error);
      return "I'm experiencing technical difficulties. Please try again later.";
    }
  }
  async generateChatResponse(messages, context) {
    try {
      const systemMessage = {
        role: "system",
        content: `You are an AI study assistant for a computer science student. You have access to their notes, GitHub projects, and placement questions.
        
        ${context ? `Current context:
${context}` : ""}
        
        Be helpful, educational, and reference the user's materials when relevant.`
      };
      const response = await this.client.chat.completions.create({
        model: "llama3-8b-8192",
        messages: [systemMessage, ...messages],
        max_tokens: 800,
        temperature: 0.7
      });
      return response.choices[0]?.message?.content || "I couldn't generate a response. Please try again.";
    } catch (error) {
      console.error("Grok API error:", error);
      return "I'm experiencing technical difficulties. Please try again later.";
    }
  }
  async analyzeCode(code, language) {
    try {
      const response = await this.client.chat.completions.create({
        model: "llama3-8b-8192",
        messages: [
          {
            role: "system",
            content: "You are a code analysis expert. Analyze the provided code and explain its functionality, architecture, and key components."
          },
          {
            role: "user",
            content: `Please analyze this ${language} code and explain its purpose and structure:

${code}`
          }
        ],
        max_tokens: 600,
        temperature: 0.5
      });
      return response.choices[0]?.message?.content || "Code analysis unavailable.";
    } catch (error) {
      console.error("Code analysis error:", error);
      return "Failed to analyze code.";
    }
  }
};

// server/services/ragService.ts
var RAGService = class {
  static groqService = new GroqService();
  static async searchAndAnswer(userId, query) {
    console.log(`\u{1F50D} RAG Search - User: ${userId}, Query: "${query}"`);
    try {
      const queryEmbedding = await FileProcessor.createEmbedding(query);
      const notes2 = await storage.getNotesByUser(userId);
      const relevantNotes = this.findRelevantNotes(notes2, queryEmbedding, query);
      console.log(`\u{1F4DD} Found ${notes2.length} total notes, ${relevantNotes.length} relevant`);
      const questions = await storage.getPlacementQuestionsByUser(userId);
      const relevantQuestions = this.findRelevantQuestions(questions, queryEmbedding, query);
      console.log(`\u2753 Found ${questions.length} total questions, ${relevantQuestions.length} relevant`);
      const githubRepos2 = await storage.getGithubReposByUser(userId);
      const relevantRepos = this.findRelevantRepos(githubRepos2, queryEmbedding, query);
      console.log(`\u{1F419} Found ${githubRepos2.length} total GitHub repos for user ${userId}`);
      console.log(`\u{1F419} Found ${relevantRepos.length} relevant GitHub repos for query: ${query}`);
      const sources = [
        ...relevantNotes.map((note) => ({
          type: "note",
          title: note.title,
          content: note.content.substring(0, 500) + (note.content.length > 500 ? "..." : ""),
          relevance: this.calculateRelevance(note.content, query)
        })),
        ...relevantQuestions.map((question) => ({
          type: "question",
          title: `${question.company} - ${question.topic}`,
          content: question.question,
          relevance: this.calculateRelevance(question.question, query)
        })),
        ...relevantRepos.map((repo) => {
          console.log(`\u{1F419} Adding GitHub repo to sources: ${repo.repoName}`);
          return {
            type: "github",
            title: repo.repoName,
            content: this.formatRepoContent(repo),
            relevance: this.calculateRelevance(`${repo.repoName} ${repo.description} ${JSON.stringify(repo.analysis)}`, query)
          };
        })
      ].sort((a, b) => b.relevance - a.relevance).slice(0, 5);
      console.log(`Final sources breakdown:`, sources.map((s) => ({ type: s.type, title: s.title, relevance: s.relevance })));
      const context = sources.map(
        (source) => `[${source.type.toUpperCase()}] ${source.title}:
${source.content}`
      ).join("\n\n");
      const answer = await this.groqService.generateAnswer(query, context);
      return {
        answer,
        sources
      };
    } catch (error) {
      console.error("RAG Service error:", error);
      throw new Error("Failed to generate answer");
    }
  }
  static findRelevantNotes(notes2, queryEmbedding, query) {
    return notes2.filter((note) => {
      const queryLower = query.toLowerCase();
      const contentLower = note.content.toLowerCase();
      const titleLower = note.title.toLowerCase();
      return contentLower.includes(queryLower) || titleLower.includes(queryLower) || this.calculateTextSimilarity(note.embedding || "", queryEmbedding) > 0.3;
    }).slice(0, 3);
  }
  static findRelevantQuestions(questions, queryEmbedding, query) {
    return questions.filter((question) => {
      const queryLower = query.toLowerCase();
      const questionLower = question.question.toLowerCase();
      const topicLower = question.topic.toLowerCase();
      return questionLower.includes(queryLower) || topicLower.includes(queryLower) || this.calculateTextSimilarity(question.embedding || "", queryEmbedding) > 0.3;
    }).slice(0, 2);
  }
  static calculateTextSimilarity(embedding1, embedding2) {
    if (!embedding1 || !embedding2) return 0;
    return FileProcessor.calculateSimilarity(embedding1, embedding2);
  }
  static calculateRelevance(content, query) {
    const queryWords = query.toLowerCase().split(/\s+/);
    const contentLower = content.toLowerCase();
    let matches = 0;
    queryWords.forEach((word) => {
      if (contentLower.includes(word)) {
        matches++;
      }
    });
    return matches / queryWords.length;
  }
  static findRelevantRepos(repos, queryEmbedding, query) {
    const queryLower = query.toLowerCase();
    const isProjectQuery = queryLower.includes("file") || queryLower.includes("structure") || queryLower.includes("project") || queryLower.includes("repo") || queryLower.includes("code") || queryLower.includes("folder") || queryLower.includes("directory") || queryLower.includes("architecture") || queryLower.includes("technology") || queryLower.includes("stack") || queryLower.includes("github");
    console.log(`\u{1F50D} Query "${query}" - isProjectQuery: ${isProjectQuery}, available repos: ${repos.length}`);
    const relevantRepos = repos.filter((repo) => {
      const repoNameLower = repo.repoName.toLowerCase();
      const descriptionLower = (repo.description || "").toLowerCase();
      const analysisText = repo.analysis ? JSON.stringify(repo.analysis).toLowerCase() : "";
      const exactMatch = repoNameLower.includes(queryLower) || descriptionLower.includes(queryLower) || analysisText.includes(queryLower);
      const shouldInclude = exactMatch || isProjectQuery && repo.analysis;
      console.log(`\u{1F50D} Checking repo ${repo.repoName}: exactMatch=${exactMatch}, hasAnalysis=${!!repo.analysis}, shouldInclude=${shouldInclude}`);
      return shouldInclude;
    });
    if (relevantRepos.length === 0 && isProjectQuery && repos.length > 0) {
      console.log(`\u{1F50D} No exact matches, returning analyzed repos for project query`);
      return repos.filter((repo) => repo.analysis).slice(0, 3);
    }
    return relevantRepos.slice(0, 3);
  }
  static formatRepoContent(repo) {
    let content = `Repository: ${repo.repoName}
`;
    if (repo.description) {
      content += `Description: ${repo.description}
`;
    }
    if (repo.language) {
      content += `Primary Language: ${repo.language}
`;
    }
    if (repo.stars) {
      content += `Stars: ${repo.stars}
`;
    }
    if (repo.analysis) {
      const analysis = repo.analysis;
      if (analysis.summary) {
        content += `
Summary: ${analysis.summary}
`;
      }
      if (analysis.technologies && Array.isArray(analysis.technologies)) {
        content += `Technologies: ${analysis.technologies.join(", ")}
`;
      }
      if (analysis.architecture) {
        content += `Architecture: ${analysis.architecture}
`;
      }
      if (analysis.keyFiles && Array.isArray(analysis.keyFiles)) {
        content += `
Key Files:
`;
        analysis.keyFiles.slice(0, 3).forEach((file) => {
          content += `- ${file.name}: ${file.purpose || "No description"}
`;
        });
      }
    }
    return content;
  }
};

// server/services/githubService.ts
import { Octokit } from "@octokit/rest";
var GitHubService = class {
  octokit = null;
  constructor(token) {
    if (token) {
      this.octokit = new Octokit({ auth: token });
    }
  }
  async fetchUserRepositories(userId, token) {
    try {
      this.octokit = new Octokit({ auth: token });
      const { data: repos } = await this.octokit.rest.repos.listForAuthenticatedUser({
        visibility: "private",
        sort: "updated",
        per_page: 50
      });
      const savedRepos = [];
      for (const repo of repos) {
        if (repo.private) {
          const repoData = {
            userId,
            repoName: repo.full_name,
            description: repo.description || "",
            language: repo.language || "Unknown",
            stars: repo.stargazers_count || 0
          };
          const savedRepo = await storage.createGithubRepo(repoData);
          savedRepos.push(savedRepo);
        }
      }
      return savedRepos;
    } catch (error) {
      console.error("GitHub API error:", error);
      throw new Error("Failed to fetch repositories");
    }
  }
  async analyzeRepository(userId, repoId, repoName) {
    try {
      if (!this.octokit) {
        throw new Error("GitHub token not configured");
      }
      const [owner, repo] = repoName.split("/");
      const { data: contents } = await this.octokit.rest.repos.getContent({
        owner,
        repo,
        path: ""
      });
      let readme = "";
      try {
        const { data: readmeData } = await this.octokit.rest.repos.getReadme({
          owner,
          repo
        });
        readme = Buffer.from(readmeData.content, "base64").toString("utf-8");
      } catch {
      }
      const keyFiles = [];
      if (Array.isArray(contents)) {
        const importantFiles = contents.filter(
          (item) => item.type === "file" && (item.name.includes("package.json") || item.name.includes("requirements.txt") || item.name.includes("app.js") || item.name.includes("main.py") || item.name.includes("index.js") || item.name.includes("server.js"))
        ).slice(0, 3);
        for (const file of importantFiles) {
          try {
            const { data: fileData } = await this.octokit.rest.repos.getContent({
              owner,
              repo,
              path: file.name
            });
            if ("content" in fileData) {
              const content = Buffer.from(fileData.content, "base64").toString("utf-8");
              keyFiles.push({
                name: file.name,
                content: content.substring(0, 1e3),
                // Limit content
                purpose: this.inferFilePurpose(file.name, content)
              });
            }
          } catch {
          }
        }
      }
      const technologies = this.extractTechnologies(keyFiles, readme);
      const analysis = {
        summary: this.generateSummary(readme, keyFiles),
        technologies,
        keyFiles,
        architecture: this.inferArchitecture(keyFiles, technologies)
      };
      await storage.updateGithubRepoAnalysis(repoId, analysis);
      return analysis;
    } catch (error) {
      console.error("Repository analysis error:", error);
      throw new Error("Failed to analyze repository");
    }
  }
  extractTechnologies(keyFiles, readme) {
    const techs = /* @__PURE__ */ new Set();
    const content = (keyFiles.map((f) => f.content).join(" ") + " " + readme).toLowerCase();
    const techMap = {
      "react": ["react", "jsx", "create-react-app"],
      "node.js": ["node", "express", "npm"],
      "python": ["python", "django", "flask", "pip"],
      "mongodb": ["mongodb", "mongoose"],
      "postgresql": ["postgresql", "postgres", "pg"],
      "javascript": ["javascript", "js"],
      "typescript": ["typescript", "ts"],
      "html": ["html"],
      "css": ["css", "styling"],
      "tailwind": ["tailwind"],
      "bootstrap": ["bootstrap"]
    };
    Object.entries(techMap).forEach(([tech, keywords]) => {
      if (keywords.some((keyword) => content.includes(keyword))) {
        techs.add(tech);
      }
    });
    return Array.from(techs);
  }
  inferFilePurpose(fileName, content) {
    if (fileName === "package.json") return "Project dependencies and configuration";
    if (fileName === "requirements.txt") return "Python dependencies";
    if (fileName.includes("app.") || fileName.includes("server.")) return "Main application entry point";
    if (fileName.includes("index.")) return "Application entry point";
    return "Configuration or main application file";
  }
  generateSummary(readme, keyFiles) {
    if (readme) {
      const lines = readme.split("\n").filter((line) => line.trim().length > 0);
      const description = lines.find((line) => !line.startsWith("#") && line.length > 20);
      if (description) return description.substring(0, 200);
    }
    return `Project with ${keyFiles.length} key files including ${keyFiles.map((f) => f.name).join(", ")}`;
  }
  inferArchitecture(keyFiles, technologies) {
    const hasBackend = keyFiles.some(
      (f) => f.name.includes("server") || f.name.includes("app.js") || f.name.includes("main.py")
    );
    const hasFrontend = technologies.includes("react") || technologies.includes("html");
    if (hasBackend && hasFrontend) return "Full-stack application";
    if (hasBackend) return "Backend API service";
    if (hasFrontend) return "Frontend application";
    return "Application project";
  }
};

// server/routes.ts
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import multer from "multer";
import fs2 from "fs";
var JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
var upload = multer({ dest: "uploads/" });
var getUserId = (req, res) => {
  const userId = req.user?.userId;
  if (!userId) {
    res.status(401).json({ message: "Unauthorized" });
    return null;
  }
  return userId;
};
var authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  if (!token) {
    return res.status(401).json({ message: "Access token required" });
  }
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: "Invalid token" });
    }
    req.user = user;
    next();
  });
};
async function registerRoutes(app2) {
  app2.post("/api/auth/register", async (req, res) => {
    try {
      const { email, password, name } = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }
      const hashedPassword = await bcrypt.hash(password, 12);
      const user = await storage.createUser({ email, password: hashedPassword, name });
      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET);
      res.json({
        token,
        user: { id: user.id, email: user.email, name: user.name }
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid registration data" });
    }
  });
  app2.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET);
      res.json({
        token,
        user: { id: user.id, email: user.email, name: user.name }
      });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });
  app2.post("/api/notes/upload", authenticateToken, upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      const { subject } = req.body;
      const userId = req.user?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const processedFile = await FileProcessor.processFile(req.file.path, req.file.originalname);
      const embedding = await FileProcessor.createEmbedding(processedFile.content);
      const note = await storage.createNote({
        userId,
        title: processedFile.title,
        content: processedFile.content,
        subject: subject || "General",
        fileType: processedFile.fileType,
        fileName: req.file.originalname
      });
      await storage.updateNoteEmbedding(note.id, embedding);
      fs2.unlinkSync(req.file.path);
      res.json({ message: "File uploaded successfully", note });
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ message: "Failed to process file" });
    }
  });
  app2.get("/api/notes", authenticateToken, async (req, res) => {
    try {
      const userId = getUserId(req, res);
      if (!userId) return;
      const { subject } = req.query;
      const notes2 = subject ? await storage.getNotesBySubject(userId, subject) : await storage.getNotesByUser(userId);
      res.json(notes2);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notes" });
    }
  });
  app2.get("/api/notes/search", authenticateToken, async (req, res) => {
    try {
      const userId = getUserId(req, res);
      if (!userId) return;
      const { q } = req.query;
      if (!q) {
        return res.status(400).json({ message: "Query parameter required" });
      }
      const notes2 = await storage.searchNotes(userId, q);
      res.json(notes2);
    } catch (error) {
      res.status(500).json({ message: "Search failed" });
    }
  });
  app2.delete("/api/notes/:noteId", authenticateToken, async (req, res) => {
    try {
      const { noteId } = req.params;
      const userId = getUserId(req, res);
      if (!userId) return;
      const note = await storage.getNoteById(noteId);
      if (!note || note.userId !== userId) {
        return res.status(404).json({ message: "Note not found" });
      }
      await storage.deleteNote(noteId);
      res.json({ message: "Note deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete note" });
    }
  });
  app2.post("/api/github/connect", authenticateToken, async (req, res) => {
    try {
      const { token } = req.body;
      const userId = getUserId(req, res);
      if (!userId) return;
      await storage.updateUser(userId, { githubToken: token });
      const githubService = new GitHubService(token);
      const repos = await githubService.fetchUserRepositories(userId, token);
      res.json({ message: "GitHub connected successfully", repos });
    } catch (error) {
      res.status(500).json({ message: "Failed to connect GitHub" });
    }
  });
  app2.post("/api/github/connect-username", authenticateToken, async (req, res) => {
    try {
      const { username } = req.body;
      const userId = getUserId(req, res);
      if (!userId) return;
      let githubUsername = username;
      if (username.includes("github.com/")) {
        const match = username.match(/github\.com\/([^\/\?]+)/);
        githubUsername = match ? match[1] : username;
      }
      const response = await fetch(`https://api.github.com/users/${githubUsername}/repos?per_page=100`);
      console.log(`Fetching repos for user: ${githubUsername}`);
      console.log(`GitHub API response status: ${response.status}`);
      if (!response.ok) {
        if (response.status === 404) {
          return res.status(404).json({ message: "GitHub user not found" });
        }
        throw new Error(`GitHub API error: ${response.status}`);
      }
      const githubRepos2 = await response.json();
      console.log(`Found ${githubRepos2.length} repositories for ${githubUsername}`);
      const repos = [];
      for (const repo of githubRepos2) {
        const repoData = {
          userId,
          repoName: repo.name,
          description: repo.description,
          language: repo.language,
          stars: repo.stargazers_count
        };
        const createdRepo = await storage.createGithubRepo(repoData);
        repos.push(createdRepo);
      }
      res.json({ message: "GitHub repositories fetched successfully", repos });
    } catch (error) {
      console.error("GitHub username connection error:", error);
      res.status(500).json({ message: "Failed to fetch GitHub repositories" });
    }
  });
  app2.get("/api/github/repos", authenticateToken, async (req, res) => {
    try {
      const userId = getUserId(req, res);
      if (!userId) return;
      const repos = await storage.getGithubReposByUser(userId);
      res.json(repos);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch repositories" });
    }
  });
  app2.post("/api/github/analyze/:repoId", authenticateToken, async (req, res) => {
    try {
      const { repoId } = req.params;
      const userId = getUserId(req, res);
      if (!userId) return;
      const user = await storage.getUser(userId);
      if (!user?.githubToken) {
        return res.status(400).json({ message: "GitHub token not configured" });
      }
      const repos = await storage.getGithubReposByUser(userId);
      const repo = repos.find((r) => r.id === repoId);
      if (!repo) {
        return res.status(404).json({ message: "Repository not found" });
      }
      const githubService = new GitHubService(user.githubToken);
      const analysis = await githubService.analyzeRepository(userId, repoId, repo.repoName);
      res.json({ analysis });
    } catch (error) {
      res.status(500).json({ message: "Failed to analyze repository" });
    }
  });
  app2.post("/api/placement/questions", authenticateToken, async (req, res) => {
    try {
      const userId = getUserId(req, res);
      if (!userId) return;
      const questionData = insertPlacementQuestionSchema.parse({ ...req.body, userId });
      const question = await storage.createPlacementQuestion(questionData);
      const embedding = await FileProcessor.createEmbedding(question.question);
      await storage.updateQuestionEmbedding(question.id, embedding);
      res.json(question);
    } catch (error) {
      res.status(400).json({ message: "Failed to create question" });
    }
  });
  app2.get("/api/placement/questions", authenticateToken, async (req, res) => {
    try {
      const userId = getUserId(req, res);
      if (!userId) return;
      const { company, year, difficulty, topic } = req.query;
      const filters = {};
      if (company) filters.company = company;
      if (year) filters.year = parseInt(year);
      if (difficulty) filters.difficulty = difficulty;
      if (topic) filters.topic = topic;
      const questions = await storage.searchPlacementQuestions(userId, filters);
      res.json(questions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch questions" });
    }
  });
  app2.post("/api/chat/sessions", authenticateToken, async (req, res) => {
    try {
      const userId = getUserId(req, res);
      if (!userId) return;
      const { title, messages } = req.body;
      const session = await storage.createChatSession({
        userId,
        title: title || "New Chat",
        messages: messages || []
      });
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to create chat session" });
    }
  });
  app2.get("/api/chat/sessions", authenticateToken, async (req, res) => {
    try {
      const userId = getUserId(req, res);
      if (!userId) return;
      const sessions = await storage.getChatSessionsByUser(userId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat sessions" });
    }
  });
  app2.delete("/api/chat/sessions", authenticateToken, async (req, res) => {
    try {
      const userId = getUserId(req, res);
      if (!userId) return;
      await storage.deleteChatSessionsByUser(userId);
      res.json({ message: "All chat sessions deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete chat sessions" });
    }
  });
  app2.post("/api/chat/:sessionId/message", authenticateToken, async (req, res) => {
    try {
      const { sessionId } = req.params;
      const { message } = req.body;
      const userId = getUserId(req, res);
      if (!userId) return;
      const sessions = await storage.getChatSessionsByUser(userId);
      const session = sessions.find((s) => s.id === sessionId);
      if (!session) {
        return res.status(404).json({ message: "Chat session not found" });
      }
      const messages = [...session.messages, { role: "user", content: message }];
      const ragResponse = await RAGService.searchAndAnswer(userId, message);
      const assistantMessage = { role: "assistant", content: ragResponse.answer, sources: ragResponse.sources };
      messages.push(assistantMessage);
      await storage.updateChatSession(sessionId, messages);
      res.json({ message: assistantMessage });
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ message: "Failed to process message" });
    }
  });
  app2.post("/api/search", authenticateToken, async (req, res) => {
    try {
      const userId = getUserId(req, res);
      if (!userId) return;
      const { query } = req.body;
      if (!query) {
        return res.status(400).json({ message: "Query is required" });
      }
      const response = await RAGService.searchAndAnswer(userId, query);
      res.json(response);
    } catch (error) {
      res.status(500).json({ message: "Search failed" });
    }
  });
  app2.get("/api/dashboard/stats", authenticateToken, async (req, res) => {
    try {
      const userId = getUserId(req, res);
      if (!userId) return;
      const [notes2, repos, questions, sessions] = await Promise.all([
        storage.getNotesByUser(userId),
        storage.getGithubReposByUser(userId),
        storage.getPlacementQuestionsByUser(userId),
        storage.getChatSessionsByUser(userId)
      ]);
      const stats = {
        totalNotes: notes2.length,
        totalRepos: repos.length,
        totalQuestions: questions.length,
        solvedQuestions: questions.filter((q) => q.isSolved).length,
        chatSessions: sessions.length
      };
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs3 from "fs";
import path3 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path2 from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path2.resolve(import.meta.dirname, "client", "src"),
      "@shared": path2.resolve(import.meta.dirname, "shared"),
      "@assets": path2.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path2.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path2.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path3.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs3.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path3.resolve(import.meta.dirname, "public");
  if (!fs3.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path3.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path4 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path4.startsWith("/api")) {
      let logLine = `${req.method} ${path4} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
